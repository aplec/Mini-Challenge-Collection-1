import UIKit

enum StudentYear: Int {
    case freshman, sophomore, junior, senior
}

struct Student {
    let firstName: String
    let lastName: String
    let id: Int
    let year: StudentYear
    let grade: Int
    
    init(firstName: String, lastName: String) {
        self.firstName = firstName
        self.lastName = lastName
        self.id  = Int(arc4random_uniform(1000))
        self.year = StudentYear(rawValue: Int(arc4random_uniform(4))) ?? .freshman
        self.grade = Int(arc4random_uniform(101))
    }
}

var students: [Student] = [
    Student(firstName: "Bob", lastName: "Jones"),
    Student(firstName: "Joe", lastName: "Thomas"),
    Student(firstName: "Evan", lastName: "Smith"),
]



let freshman = students.filter({
    (student) in
    return student.year == StudentYear.freshman
})

for student in freshman {
    print("\(student.firstName) is a \(student.year).")
}



let names = students.map {
    (student) in
    return student.firstName + " " + student.lastName
}

for name in names {
    print(name)
}



var total = 0

for student in students {
    print("\(student.firstName): \(student.grade)%")
    total += student.grade
}

print("Cumulative Class Score: \(total)")
let avg = total / students.count
print("Class Average: \(avg)")


